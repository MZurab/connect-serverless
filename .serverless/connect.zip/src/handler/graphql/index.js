"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const { ApolloServer, gql } = require('apollo-server-lambda');
// Construct a schema, using GraphQL schema language
const typeDefs = gql `
  type Query {
    hello: String
    hello2: String
  }
`;
// Provide resolver functions for your schema fields
const resolvers = {
    Query: {
        hello: () => 'Hello world - 1!',
        hello2: () => 'Hello world - 2!',
    }
};
const server = new ApolloServer({
    typeDefs,
    resolvers,
});
const handler = server.createHandler({
    cors: {
        origin: true,
        credentials: true,
    },
});
exports.handler = handler;
//# sourceMappingURL=index.js.map
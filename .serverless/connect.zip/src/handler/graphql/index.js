"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const lambdaApollo_1 = require("../../../node_modules/apollo-server-lambda/dist/lambdaApollo");
const graphql_tools_1 = require("graphql-tools");
const lodash_1 = require("lodash");
const dictionary_graphql_resolver_1 = require("./dictionary/dictionary.graphql.resolver");
const dictionary_graphql_typedef_1 = require("./dictionary/dictionary.graphql.typedef");
// Construct a schema, using GraphQL schema language
const typeDefs = `
    type Query {
        _empty: String
    }
    
    extend type Query {
        test: Test
    }

    type Test {
        val: String
    }
`;
// Provide resolver functions for your schema fields
const resolvers = {
    Query: {
        test: () => { return { "val": "it is test" }; }
    }
};
// @ts-ignore
const myGraphQLSchema = graphql_tools_1.makeExecutableSchema({
    // add with all types in array
    typeDefs: [typeDefs, dictionary_graphql_typedef_1.DictionaryTypeDef],
    // add all resolver with lodash method merge
    resolvers: lodash_1.merge(dictionary_graphql_resolver_1.GraphQlResolver, resolvers),
});
const handler = function graphqlHandler(event, context, callback) {
    // create handler
    const handler = lambdaApollo_1.graphqlLambda({ schema: myGraphQLSchema });
    // return handler
    return handler(event, context, (error, output) => {
        // eslint-disable-next-line no-param-reassign
        // @ts-ignore
        output.headers['Access-Control-Allow-Origin'] = '*';
        callback(error, output);
    });
};
exports.handler = handler;
//# sourceMappingURL=index.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const rxjs_1 = require("rxjs");
const dynamo_1 = require("../../../input/aws/dynamo/dynamo");
const crypto = require("crypto");
var Dictionary;
(function (Dictionary) {
    const tableNameDictionary = "connect-dictionary";
    function get(uid) {
        return rxjs_1.Observable.create((observer) => {
            getDictionary(uid).subscribe((dictionary) => {
                let status = !!dictionary, result = {
                    status: status,
                    dictionary: dictionary,
                    includedLanguages: ['ru', 'en'],
                    possibleLanguages: ['ru', 'en'],
                    defaultLanguage: 'ru',
                    hash: crypto.createHash('md5').update(JSON.stringify(dictionary)).digest("hex")
                };
                observer.next(result);
                observer.complete();
            });
        });
    }
    Dictionary.get = get;
    function getDictionary(uid) {
        return rxjs_1.Observable.create((observer) => {
            let objForQuery = { 'table': tableNameDictionary, 'index': 'uid-status-index' };
            objForQuery = dynamo_1.MzDynamoDb.addByMask({ 'status': 0 }, 'status', objForQuery, 'number');
            objForQuery = dynamo_1.MzDynamoDb.addByMask({ 'uid': uid }, 'uid', objForQuery);
            dynamo_1.MzDynamoDb.query(objForQuery).subscribe((d) => {
                let err = d.err, data = d.data;
                if (!err && data.Count > 0) {
                    // let result = collectForResponce(data.Items,lang);
                    observer.next(collectForResponce(data.Items));
                    return;
                }
                else {
                    observer.next(null);
                }
                observer.complete();
            });
        });
    }
    function collectForResponce(items) {
        return items.reduce((acumulator, item) => {
            let prefix = item.key;
            for (let key of Object.keys(item.values)) {
                acumulator.push({
                    key: `${prefix}.${key}`,
                    value: item.values[key]
                });
            }
            return acumulator;
        }, []);
    }
})(Dictionary = exports.Dictionary || (exports.Dictionary = {}));
//# sourceMappingURL=dictionary.library.js.map
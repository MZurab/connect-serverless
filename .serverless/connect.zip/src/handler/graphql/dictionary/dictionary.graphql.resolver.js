"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
// import {Mock} from "./dictionary.mock";
const dictionary_library_1 = require("./dictionary.library");
exports.GraphQlResolver = {
    Query: {
        getDictionary: () => dictionary_library_1.Dictionary.get('@system').toPromise() //Mock.Dictionary,
        // getDictionaryHash: ()  => Mock.Hash
    }
};
//# sourceMappingURL=dictionary.graphql.resolver.js.map
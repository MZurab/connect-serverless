"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const dictionary_mock_1 = require("./dictionary.mock");
const dictionary_library_1 = require("./dictionary.library");
exports.GraphQlResolver = {
    Query: {
        getDictionary: () => {
            console.log('GraphQlResolver - getDictionary INVOKE');
            let r = dictionary_library_1.Dictionary.get('@system').toPromise();
            console.log('GraphQlResolver - getDictionary', r);
            return r;
        },
        getDictionaryHash: () => dictionary_mock_1.Mock.Hash
    }
};
//# sourceMappingURL=dictionary.graphql.resolver.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Mock;
(function (Mock) {
    Mock.Dictionary = {
        status: true,
        dictionary: [
            {
                key: 'test',
                value: {
                    'ru': 'test - ru',
                    'en': 'test - en'
                }
            }
        ],
        includedLanguages: ['ru', 'en'],
        possibleLanguages: ['ru', 'en'],
        defaultLanguage: 'ru',
        hash: 'hash1'
    };
    Mock.Hash = {
        hash: 'hash1',
        status: true
    };
})(Mock = exports.Mock || (exports.Mock = {}));
//# sourceMappingURL=dictionary.mock.js.map
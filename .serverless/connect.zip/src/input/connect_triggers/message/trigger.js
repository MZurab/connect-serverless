const LOG             = require('ramman-z-log');
const FIREBASE        = require("./../../firebase/firebase");
      const firestore = FIREBASE.firestore;
const TRIGGER         = require("./../trigger");

const _ = {};



function addTriggerForEventAddMessage (iNchatId, iNobject , iNfunction, iNdb, iNbatch ) {



} _.addTriggerForEventAddMessage = addTriggerForEventAddMessage;


function getTriggerByEvent ( iNuid, iNobject , iNfunction ) {


} _.getTriggerByEvent = getTriggerByEvent;

module.exports = _;

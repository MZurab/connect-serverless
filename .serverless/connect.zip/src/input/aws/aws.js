const AWS = require("aws-sdk");
// AWS.config.update (
//
// );
module.exports.data = AWS;

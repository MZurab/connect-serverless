"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const rxjs_1 = require("rxjs");
const amazon_1 = require("../amazon");
const common_enum_1 = require("./res/@abstract/@enum/common.enum");
var MzDynamoDb;
(function (MzDynamoDb) {
    const docClient = new amazon_1.Amazon.config.DynamoDB.DocumentClient({
        region: "eu-west-1",
        endpoint: "https://dynamodb.eu-west-1.amazonaws.com"
    });
    function add(table, data) {
        return rxjs_1.Observable.create((observer) => {
            let params = {
                TableName: table,
                Item: data
            };
            docClient.put(params, function (err, data) {
                observer.next({ err, data });
                observer.complete();
            });
        });
    }
    MzDynamoDb.add = add;
    function del(obj) {
        return rxjs_1.Observable.create((observer) => {
            let params = {
                TableName: obj.table,
                Key: obj.key,
            };
            if (typeof (obj.vals) !== 'undefined' && obj.vals !== false)
                params.ExpressionAttributeValues = obj.vals;
            if (typeof (obj.mask) !== 'undefined' && obj.cond !== false)
                params.ConditionExpression = obj.cond;
            if (typeof (obj.keys) !== 'undefined' && obj.keys !== false)
                params.ExpressionAttributeNames = obj.keys; // "#yr": "year"
            docClient.delete(params, function (err, data) {
                if (err) {
                    console.error("Unable to delete item. Error JSON:", JSON.stringify(err, null, 2));
                }
                observer.next({ err, data });
                observer.complete();
            });
        });
    }
    MzDynamoDb.del = del;
    function update(obj) {
        return rxjs_1.Observable.create((observer) => {
            let params = {
                TableName: obj.table,
                ReturnValues: "UPDATED_NEW"
            };
            if (typeof obj.keys !== 'undefined' && obj.keys !== false)
                params.ExpressionAttributeNames = obj.keys; // "#yr": "year"
            if (typeof obj.key !== 'undefined' && obj.key !== false)
                params.Key = obj.key; //{ "year": year, "title": title }
            if (typeof obj.set !== 'undefined' && obj.set !== false)
                params.UpdateExpression = obj.set; // "set info.rating = :r, info.plot=:p, info.actors=:a"
            if (typeof obj.vals !== 'undefined' && obj.vals !== false)
                params.ExpressionAttributeValues = obj.vals; // ":yyyy":1985
            docClient.update(params, function (err, data) {
                if (err) {
                    console.error("Unable to update item. Error JSON:", JSON.stringify(err, null, 2));
                }
                else {
                    // LOG.printObject("UpdateItem succeeded:", JSON.stringify(data, null, 2));
                }
                observer.next({ err, data });
                observer.complete();
            });
        });
    }
    MzDynamoDb.update = update;
    function query(obj) {
        return rxjs_1.Observable.create((observer) => {
            let params = {
                TableName: obj.table
            };
            if (typeof (obj.limit) != 'undefined')
                params.Limit = obj.limit;
            if (typeof (obj.last) != 'undefined')
                params.ExclusiveStartKey = obj.last;
            if (typeof (obj.index) != 'undefined')
                params.IndexName = obj.index;
            if (typeof (obj.order) != 'undefined') {
                if (obj.order === common_enum_1.DynamoOrderTypeEnum.desc) {
                    params.ScanIndexForward = false;
                }
                else {
                    params.ScanIndexForward = true;
                }
            }
            if (typeof (obj.maskFilter) != 'undefined' && obj.maskFilter !== false)
                params.FilterExpression = obj.maskFilter; //"#yr = :yyyy",
            if (typeof (obj.select) != 'undefined' && obj.select !== false)
                params.ProjectionExpression = obj.select; // "#yr, title, info.genres, info.actors[0]",
            if (typeof (obj.mask) != 'undefined' && obj.mask !== false)
                params.KeyConditionExpression = obj.mask; //"#yr = :yyyy",
            if (typeof (obj.keys) != 'undefined' && obj.keys !== false)
                params.ExpressionAttributeNames = obj.keys; // "#yr": "year"
            if (typeof (obj.vals) != 'undefined' && obj.vals !== false)
                params.ExpressionAttributeValues = obj.vals; // ":yyyy":1985
            let data = { 'Count': 0, "Items": [], "Counter": 0, "ScannedCount": 0 };
            function callback(err, d) {
                // LOG.printObject('DinamoDbQuery err',err);
                if (err) {
                    observer.next({ err, data: null });
                    observer.complete();
                    return;
                }
                data["Counter"]++;
                if (d.Count > 0) {
                    data['Items'] = data['Items'].concat(d.Items);
                    data['Count'] += d.Count;
                }
                data['ScannedCount'] += d.ScannedCount;
                // LOG.printObject("inF",dataResult["Counter"],dataResult['Count']);
                if (typeof (d.LastEvaluatedKey) === 'object') {
                    params.ExclusiveStartKey = d.LastEvaluatedKey;
                    docClient.query(params, callback);
                }
                else {
                    // onQuery(err,dataResult);
                    observer.next({ err, data });
                    observer.complete();
                }
            }
            docClient.query(params, callback);
        });
    }
    MzDynamoDb.query = query;
    function scan(obj) {
        return rxjs_1.Observable.create((observer) => {
            let params = { TableName: obj.table };
            if (typeof (obj.limit) != 'undefined')
                params.Limit = obj.limit;
            if (typeof (obj.last) != 'undefined')
                params.ExclusiveStartKey = obj.last;
            if (typeof (obj.index) != 'undefined')
                params.IndexName = obj.index;
            if (typeof (obj.order) != 'undefined') {
                if (obj.order == 'desc') {
                    params.ScanIndexForward = false;
                }
                else {
                    params.ScanIndexForward = true;
                }
            }
            if (typeof (obj.select) != 'undefined' && obj.select !== false)
                params.ProjectionExpression = obj.select; // "#yr, title, info.genres, info.actors[0]",
            if (typeof (obj.mask) != 'undefined' && obj.mask !== false)
                params.FilterExpression = obj.mask; //"#yr = :yyyy",
            if (typeof (obj.keys) != 'undefined' && obj.keys !== false)
                params.ExpressionAttributeNames = obj.keys; // "#yr": "year"
            if (typeof (obj.vals) != 'undefined' && obj.vals !== false)
                params.ExpressionAttributeValues = obj.vals; // ":yyyy":1985
            docClient.scan(params, (err, data) => {
                observer.next({ err, data });
                observer.complete();
            });
        });
    }
    MzDynamoDb.scan = scan;
    function addByMask(iNdata, iNname, iNresult, iNtype, iNmark) {
        return _addBy(iNdata, iNname, iNresult, iNtype, iNmark, "mask");
    }
    MzDynamoDb.addByMask = addByMask;
    function addByMaskFilter(iNdata, iNname, iNresult, iNtype, iNmark) {
        return _addBy(iNdata, iNname, iNresult, iNtype, iNmark, "maskFilter");
    }
    MzDynamoDb.addByMaskFilter = addByMaskFilter;
    function _addBy(iNdata, iNname, iNresult, iNtype, iNmark, iNmaskType) {
        if (typeof (iNdata) != 'object' ||
            typeof (iNname) != 'string' ||
            typeof (iNmaskType) != 'string')
            return false;
        if (typeof (iNmark) != 'string')
            iNmark = "=";
        if (typeof (iNtype) != 'string')
            iNtype = "string";
        if (iNmaskType == 'mask')
            iNresult = checkForMask(iNresult);
        else if (iNmaskType == 'maskFilter')
            iNresult = checkForMaskFilter(iNresult);
        let arrayOfNames = iNname.split('.'), nameForAdd, valNameForAdd, nameArrayForAdd = [];
        for (let iKey in arrayOfNames) {
            // iKey *= 1; - I DONT WHY IS NEED
            if (arrayOfNames.length == (iKey + 1)) {
                // add value if last
                if (typeof (iNdata[arrayOfNames[iKey]]) != iNtype)
                    return false;
                iNresult['vals'][":" + arrayOfNames[iKey]] = iNdata[arrayOfNames[iKey]];
                valNameForAdd = ':' + arrayOfNames[iKey];
            }
            // add key to path
            iNresult['keys'][`#${arrayOfNames[iKey]}`] = arrayOfNames[iKey];
            // @ts-ignore
            nameArrayForAdd.push(`#${arrayOfNames[iKey]}`);
        }
        nameForAdd = nameArrayForAdd.join('.');
        if (iNresult[iNmaskType].length > 0)
            iNresult[iNmaskType] += " and ";
        iNresult[iNmaskType] += nameForAdd + " " + iNmark + " " + valNameForAdd;
        return iNresult;
    }
    function checkForMask(iNresult) {
        return checkPrivate(iNresult, "mask");
    }
    function checkForMaskFilter(iNresult) {
        return checkPrivate(iNresult, "maskFilter");
    }
    function checkPrivate(iNresult, iNname) {
        if (typeof (iNresult) != 'object')
            iNresult = {};
        if (typeof (iNresult['keys']) != 'object')
            iNresult['keys'] = {};
        if (typeof (iNresult['vals']) != 'object')
            iNresult['vals'] = {};
        if (typeof (iNresult[iNname]) != 'string')
            iNresult[iNname] = '';
        return iNresult;
    }
})(MzDynamoDb = exports.MzDynamoDb || (exports.MzDynamoDb = {}));
//# sourceMappingURL=dynamo.js.map
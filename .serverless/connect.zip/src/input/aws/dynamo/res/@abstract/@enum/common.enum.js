"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var DynamoOrderTypeEnum;
(function (DynamoOrderTypeEnum) {
    DynamoOrderTypeEnum["asc"] = "asc";
    DynamoOrderTypeEnum["desc"] = "desc";
})(DynamoOrderTypeEnum = exports.DynamoOrderTypeEnum || (exports.DynamoOrderTypeEnum = {}));
//# sourceMappingURL=common.enum.js.map
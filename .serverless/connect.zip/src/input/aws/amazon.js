"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws = require("aws-sdk");
var Amazon;
(function (Amazon) {
    Amazon.config = aws;
})(Amazon = exports.Amazon || (exports.Amazon = {}));
//# sourceMappingURL=amazon.js.map
const CONNECT = require('../../../connect');
const LOG = require('ramman-z-log');
const FIREBASE = require("../../../firebase/firebase");
const firestore = FIREBASE.firestore;
class FreeformGroupModel {
    constructor() {
    }
}
module.exports.FreeformGroupModel = FreeformGroupModel;
//# sourceMappingURL=FreeformGroupModel.js.map
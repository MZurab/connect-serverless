const CONNECT = require('../../../connect');
const LOG = require('ramman-z-log');
const FIREBASE = require("../../../firebase/firebase");
const firestore = FIREBASE.firestore;
class FreeformRowModel {
    constructor() {
    }
}
module.exports.FreeformRowModel = FreeformRowModel;
//# sourceMappingURL=FreeformRowModel.js.map
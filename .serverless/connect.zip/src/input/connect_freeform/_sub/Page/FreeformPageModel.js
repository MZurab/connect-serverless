const CONNECT = require('../../../connect');
const LOG = require('ramman-z-log');
const FIREBASE = require("../../../firebase/firebase");
const firestore = FIREBASE.firestore;
class FreeformPageModel {
    constructor() {
    }
}
module.exports.FreeformPageModel = FreeformPageModel;
//# sourceMappingURL=FreeformPageModel.js.map
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const crypto = require("crypto");
// import * as http from 'http';
const _uuid_ = require("node-uuid");
const request = require("request");
const rxjs_1 = require("rxjs");
var Connect;
(function (Connect) {
    function getUrlHttpsRequest(url) {
        return rxjs_1.Observable.create((observer) => {
            request(url, (error, response, body) => {
                observer.next({ error, response, body });
                observer.complete();
            });
        });
    }
    Connect.getUrlHttpsRequest = getUrlHttpsRequest;
    function getRandomKeyByUuid() {
        return _uuid_.v4();
    }
    Connect.getRandomKeyByUuid = getRandomKeyByUuid;
    function clearHtml(data) {
        return data.replace(/[\t\n ]+/g, ' ');
    }
    Connect.clearHtml = clearHtml;
    function addVarsToPage(obj) {
        if (typeof (obj) != 'object')
            return '';
        let result = '';
        for (let iKey in obj) {
            result += "let " + iKey + " = '" + obj[iKey] + "';";
        }
        return result;
    }
    Connect.addVarsToPage = addVarsToPage;
    function getTime() {
        return new Date().getTime();
    }
    Connect.getTime = getTime;
    // generate Random values from limited set of characters NEED CRYPTO var crypto = require('crypto');
    function getRandomKeyWithChars(amountChars, chars) {
        chars = chars
            || "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
        let rnd = crypto.randomBytes(amountChars), value = new Array(amountChars), len = chars.length;
        for (var i = 0; i < amountChars; i++) {
            value[i] = chars[rnd[i] % len];
        }
        return value.join('');
    }
    Connect.getRandomKeyWithChars = getRandomKeyWithChars;
    function getRandomNubmer(amountChars) {
        if (typeof (amountChars) !== 'number')
            amountChars = 5;
        return getRandomKeyWithChars(amountChars, "0123456789");
    }
    Connect.getRandomNubmer = getRandomNubmer;
    const _algorithm_ = 'aes-256-ctr', _password_ = 'd6F3Efeq';
    function encryptByAes(text) {
        let cipher = crypto.createCipher(_algorithm_, _password_), crypted = cipher.update(text, 'utf8', 'hex');
        crypted += cipher.final('hex');
        return crypted;
    }
    Connect.encryptByAes = encryptByAes;
    function decryptByAes(text) {
        let decipher = crypto.createDecipher(_algorithm_, _password_), dec = decipher.update(text, 'hex', 'utf8');
        dec += decipher.final('utf8');
        return dec;
    }
    Connect.decryptByAes = decryptByAes;
    function createHashMd5(text) {
        // NodeJS create md5 hash from string
        // https://gist.github.com/kitek/1579117/8cd97e0d85c3fca35036d4f76dd6f32d8ffe1e46
        return crypto.createHash('md5').update(text).digest("hex");
    }
    Connect.createHashMd5 = createHashMd5;
    var headerFromJs;
    function setHeader(iNheaderFromJs) {
        headerFromJs = iNheaderFromJs;
    }
    Connect.setHeader = setHeader;
    function getHeaderByKey(iNkey, iNheaderFromJs) {
        let headerFromJsIn;
        if (typeof (iNheaderFromJs) === 'object')
            headerFromJsIn = iNheaderFromJs;
        else
            headerFromJsIn = headerFromJs;
        return headerFromJsIn['params']["header"][iNkey];
    }
    Connect.getHeaderByKey = getHeaderByKey;
    function getDataFromBasicAuthFromHeader() {
        let headerAuthorization = getHeaderByKey('Authorization');
        if (typeof headerAuthorization === 'string') {
            //delete substing
            let base64EncodeString = headerAuthorization.replace('Basic ', ''), 
            //decode this string
            decodedString = base64_decode(base64EncodeString), 
            // split this text
            arrayWithLoginAndPswd = decodedString.split(':');
            if (arrayWithLoginAndPswd.length == 2) {
                return {
                    'login': arrayWithLoginAndPswd[0],
                    'password': arrayWithLoginAndPswd[1]
                };
            }
        }
        return false;
    }
    Connect.getDataFromBasicAuthFromHeader = getDataFromBasicAuthFromHeader;
    function getHeader(iNheaderArray, iNheaderFromJs) {
        let headerFromJsIn;
        headerFromJsIn = (typeof iNheaderFromJs == 'object') ? iNheaderFromJs : headerFromJs;
        if (typeof iNheaderArray !== 'object' || Array.isArray(iNheaderArray) == false)
            iNheaderArray['*'];
        let DATA = {}, TYPE, METHOD = getMethod();
        if (METHOD == 'GET' && (iNheaderArray.indexOf('*') != -1 || iNheaderArray.indexOf('GET') != -1)) {
            TYPE = "GET",
                DATA = headerFromJsIn['params']["querystring"];
        }
        else if (iNheaderArray.indexOf('*') != -1 || iNheaderArray.indexOf('JSON') != -1) {
            TYPE = "JSON",
                DATA = headerFromJsIn["body-json"];
        }
        return { 'data': DATA, 'type': TYPE, 'header': headerFromJsIn['params']["header"] };
    }
    Connect.getHeader = getHeader;
    function getQueryString(iNheaderFromJs) {
        let headerFromJsIn, r;
        if (typeof (iNheaderFromJs) == 'object')
            headerFromJsIn = iNheaderFromJs;
        else
            headerFromJsIn = headerFromJs;
        try {
            r = headerFromJsIn['params']["querystring"];
        }
        catch (e) {
            r = false;
        }
        return r;
    }
    Connect.getQueryString = getQueryString;
    function getUrlParam(iNname, iNheaderFromJs) {
        let PATH = getUrlParams(iNheaderFromJs);
        if (typeof (PATH[iNname]) != 'undefined')
            return PATH[iNname];
        return null;
    }
    Connect.getUrlParam = getUrlParam;
    function getUrlParams(iNheaderFromJs) {
        if (typeof (iNheaderFromJs) === 'object')
            var headerFromJsIn = iNheaderFromJs;
        else
            headerFromJsIn = headerFromJs;
        return headerFromJsIn['params']['path'];
    }
    Connect.getUrlParams = getUrlParams;
    function getIp(iNheaderFromJs) {
        return getFromContext('source-ip', iNheaderFromJs);
    }
    Connect.getIp = getIp;
    function getUrl(iNheaderFromJs) {
        return getFromContext('resource-path', iNheaderFromJs);
    }
    Connect.getUrl = getUrl;
    function getUserAgent(iNheaderFromJs) {
        return getFromContext('user-agent', iNheaderFromJs);
    }
    Connect.getUserAgent = getUserAgent;
    function getMethod(iNheaderFromJs) {
        return getFromContext('http-method', iNheaderFromJs);
    }
    Connect.getMethod = getMethod;
    function getFromContext(iNname, iNheaderFromJs) {
        if (typeof (iNheaderFromJs) === 'object')
            var headerFromJsIn = iNheaderFromJs;
        else
            headerFromJsIn = headerFromJs;
        var r;
        try {
            r = headerFromJsIn['context'][iNname];
        }
        catch (e) {
            r = {};
        }
        finally {
            return r;
        }
    }
    Connect.getFromContext = getFromContext;
    // Create Base64 Object
    var Base64 = { _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", encode: function (e) { var t = ""; var n, r, i, s, o, u, a; var f = 0; e = Base64._utf8_encode(e); while (f < e.length) {
            n = e.charCodeAt(f++);
            r = e.charCodeAt(f++);
            i = e.charCodeAt(f++);
            s = n >> 2;
            o = (n & 3) << 4 | r >> 4;
            u = (r & 15) << 2 | i >> 6;
            a = i & 63;
            if (isNaN(r)) {
                u = a = 64;
            }
            else if (isNaN(i)) {
                a = 64;
            }
            t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a);
        } return t; }, decode: function (e) { var t = ""; var n, r, i; var s, o, u, a; var f = 0; e = e.replace(/[^A-Za-z0-9+/=]/g, ""); while (f < e.length) {
            s = this._keyStr.indexOf(e.charAt(f++));
            o = this._keyStr.indexOf(e.charAt(f++));
            u = this._keyStr.indexOf(e.charAt(f++));
            a = this._keyStr.indexOf(e.charAt(f++));
            n = s << 2 | o >> 4;
            r = (o & 15) << 4 | u >> 2;
            i = (u & 3) << 6 | a;
            t = t + String.fromCharCode(n);
            if (u != 64) {
                t = t + String.fromCharCode(r);
            }
            if (a != 64) {
                t = t + String.fromCharCode(i);
            }
        } t = Base64._utf8_decode(t); return t; }, _utf8_encode: function (e) { e = e.replace(/rn/g, "n"); var t = ""; for (var n = 0; n < e.length; n++) {
            var r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r);
            }
            else if (r > 127 && r < 2048) {
                t += String.fromCharCode(r >> 6 | 192);
                t += String.fromCharCode(r & 63 | 128);
            }
            else {
                t += String.fromCharCode(r >> 12 | 224);
                t += String.fromCharCode(r >> 6 & 63 | 128);
                t += String.fromCharCode(r & 63 | 128);
            }
        } return t; }, _utf8_decode: function (e) { var t = ""; var n = 0; var r = c1 = c2 = 0; while (n < e.length) {
            r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r);
                n++;
            }
            else if (r > 191 && r < 224) {
                c2 = e.charCodeAt(n + 1);
                t += String.fromCharCode((r & 31) << 6 | c2 & 63);
                n += 2;
            }
            else {
                c2 = e.charCodeAt(n + 1);
                c3 = e.charCodeAt(n + 2);
                t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
                n += 3;
            }
        } return t; } };
    function base64_encode(text) {
        return Base64.encode(text);
    }
    Connect.base64_encode = base64_encode;
    function base64_decode(text) {
        return Base64.decode(text);
    }
    Connect.base64_decode = base64_decode;
    function mergeObject(iNobject, iNobject2) {
        let arrOfKeys = Object.keys(iNobject2);
        for (let k of arrOfKeys) {
            //
            let el = iNobject2[k];
            if (typeof el === 'object' && !Array.isArray(el)) {
                // create object if not
                if (typeof iNobject[k] !== 'object')
                    iNobject[k] = {};
                // copy this object
                mergeObject(iNobject[k], el);
            }
            else {
                // set new val if in original object is not isset
                if (typeof iNobject[k] === 'undefined') {
                    iNobject[k] = el;
                }
            }
        }
        return iNobject;
    }
    Connect.mergeObject = mergeObject;
    function deepCopyObject(object) {
        let node;
        if (object === null) {
            node = object;
        }
        else if (Array.isArray(object)) {
            node = object.slice(0) || [];
            node.forEach(n => {
                if (typeof n === 'object' && n !== {} || Array.isArray(n)) {
                    n = deepCopyObject(n);
                }
            });
        }
        else if (typeof object === 'object') {
            node = Object.assign({}, object);
            Object.keys(node).forEach(key => {
                if (typeof node[key] === 'object' && node[key] !== {}) {
                    node[key] = deepCopyObject(node[key]);
                }
            });
        }
        else {
            node = object;
        }
        return node;
    }
    Connect.deepCopyObject = deepCopyObject;
    function returnPromiseWithValue(iNvalue) {
        return new Promise((resolve) => {
            resolve(iNvalue);
        });
    }
    Connect.returnPromiseWithValue = returnPromiseWithValue;
    function saveUid(iNuid) {
        let uid = iNuid;
        if (!global['freeform'])
            global['freeform'] = {};
        global['freeform']['uid'] = uid;
    }
    Connect.saveUid = saveUid;
    function getUid() {
        if (!global['freeform'])
            return false;
        if (!global['freeform']['uid'])
            return false;
        return global['freeform']['uid'];
    }
    Connect.getUid = getUid;
})(Connect = exports.Connect || (exports.Connect = {}));
//# sourceMappingURL=connect.js.map